//
//  BarangCell.swift
//  testBuanaVariaUtama
//
//  Created by Aries Dwi Prasetiyo on 02/12/20.
//  Copyright © 2020 Aries Dwi Prasetiyo. All rights reserved.
//

import UIKit

class BarangCell: UICollectionViewCell {

    @IBOutlet var BarangimageView: UIImageView!
    @IBOutlet var BarangNameLabel: UILabel!
    @IBOutlet var priceLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
