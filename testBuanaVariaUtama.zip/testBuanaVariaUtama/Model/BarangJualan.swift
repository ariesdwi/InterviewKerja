//
//  File.swift
//  testBuanaVariaUtama
//
//  Created by Aries Dwi Prasetiyo on 02/12/20.
//  Copyright © 2020 Aries Dwi Prasetiyo. All rights reserved.
//

import Foundation

struct BarangJualan {
    
    var id:Int
    var name:String
    var category:String
    var variant:String
    var price:Int
    var images:String
    var Discount:Int
    var description:String
    
}
